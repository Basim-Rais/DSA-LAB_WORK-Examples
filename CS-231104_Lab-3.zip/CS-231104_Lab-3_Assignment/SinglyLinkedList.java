/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA;

/**
 *
 * @author Pcw
 */
class SinglyLinkedList {
    Node head;
    
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Task 1
    public int getLength() {
        int length = 0;
        Node temp = head;
        while (temp != null) {
            length++;
            temp = temp.next;
        }
        return length;
    }

    // Task 2. 
    public void printMiddleNode() {
        Node slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        if (slow != null) {
            System.out.println("Middle node: " + slow.data);
        }
    }

    // Task 3. 
    public SinglyLinkedList reverseCopy() {
        SinglyLinkedList reversedList = new SinglyLinkedList();
        Node temp = head;
        while (temp != null) {
            Node newNode = new Node(temp.data);
            newNode.next = reversedList.head;
            reversedList.head = newNode;
            temp = temp.next;
        }
        return reversedList;
    }

    // Task 4.
    public void removeDuplicates() {
        Node current = head;
        while (current != null && current.next != null) {
            if (current.data == current.next.data) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
    }

    // Task 5. 
    public static SinglyLinkedList mergeSorted(SinglyLinkedList list1, SinglyLinkedList list2) {
        Node temp = new Node(0);
        Node tail = temp, a = list1.head, b = list2.head;

        while (a != null && b != null) {
            if (a.data <= b.data) {
                tail.next = a;
                a = a.next;
            } else {
                tail.next = b;
                b = b.next;
            }
            tail = tail.next;
        }

        if (a != null) tail.next = a;
        if (b != null) tail.next = b;

        SinglyLinkedList mergedList = new SinglyLinkedList();
        mergedList.head = temp.next;
        return mergedList;
    }

    // Task 6. 
    public void deleteComplete() {
        head = null;
        System.out.println("List deleted.");
    }

    
    public void addNode(int data) {
        if (head == null) {
            head = new Node(data);
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = new Node(data);
        }
    }

    
    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.addNode(1);
        list.addNode(2);
        list.addNode(2);
        list.addNode(3);
        list.addNode(4);

        System.out.println("Original list:");
        list.printList();

      
        System.out.println("Length is : " + list.getLength());

      
        list.printMiddleNode();

      
        SinglyLinkedList reversedList = list.reverseCopy();
        System.out.println("Reversed list:");
        reversedList.printList();

       
        list.removeDuplicates();
        System.out.println("After removing the duplicates:");
        list.printList();

        
        SinglyLinkedList list2 = new SinglyLinkedList();
        list2.addNode(0);
        list2.addNode(3);
        list2.addNode(5);
        SinglyLinkedList mergedList = SinglyLinkedList.mergeSorted(list, list2);
        System.out.println("After merging the list:");
        mergedList.printList();

       
        list.deleteComplete();
        System.out.println("After deleting list:");
        list.printList();
    }
}
