class TreeNode {
    int data;
    TreeNode left, right;

    public TreeNode(int data) {
        this.data = data;
        this.left = this.right = null;
    }
}

public class BinaryTree {
    
   
    public static int calculateLevel(TreeNode root) {
        if (root == null) return 0;
        int leftHeight = calculateLevel(root.left);
        int rightHeight = calculateLevel(root.right);
        return Math.max(leftHeight, rightHeight) + 1;
    }

   
    public static boolean isCompleteTree(TreeNode root) {
        if (root == null) return true;

        boolean end = false;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();

            if (current == null) {
                end = true;
            } else {
                if (end) return false;
                queue.add(current.left);
                queue.add(current.right);
            }
        }
        return true;
    }

    public static boolean isFullTree(TreeNode root) {
        if (root == null) return true;

        if ((root.left == null && root.right != null) || (root.left != null && root.right == null)) {
            return false;
        }

        return isFullTree(root.left) && isFullTree(root.right);
    }

    
    public static String checkTreeType(TreeNode root) {
        boolean isComplete = isCompleteTree(root);
        boolean isFull = isFullTree(root);

        if (isComplete && isFull) return "Both Complete and Full Tree";
        if (isComplete) return "Complete Tree";
        if (isFull) return "Full Tree";
        return "Neither Complete nor Full Tree";
    }

    
    public static boolean checkChildrenSumProperty(TreeNode root) {
        if (root == null || (root.left == null && root.right == null)) {
            return true;
        }

        int leftData = (root.left != null) ? root.left.data : 0;
        int rightData = (root.right != null) ? root.right.data : 0;

        return (root.data == leftData + rightData)
                && checkChildrenSumProperty(root.left)
                && checkChildrenSumProperty(root.right);
    }

    public static void main(String[] args) {
        // Example binary tree
        TreeNode root = new TreeNode(10);
        root.left = new TreeNode(8);
        root.right = new TreeNode(2);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(5);
        root.right.right = new TreeNode(2);

       
        System.out.println("Level of the binary tree: " + calculateLevel(root));

    
        System.out.println("Tree Type: " + checkTreeType(root));

      
        System.out.println("Children Sum Property: " + (checkChildrenSumProperty(root) ? "Satisfied" : "Not Satisfied"));
    }
}
