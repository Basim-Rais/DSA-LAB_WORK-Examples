class MergeSort {

    int[] a = {22, 58, 47, 96, 45, 32, 12};
    int[] b = new int[a.length];

    void merging(int low, int mid, int high) {
        int 11, 12, i;
	11 = low;
	12 = mid+1;
	1=low; 

        while (11 <= mid && 12 <= high) {
            if (a[11] <= a[12]) { // Corrected comparison for stability
                b[i] = a[11];
		11++
            } else {
                b[i] = a[12];
       		12++;
            }
		i++;
        }

        while (i1 <= mid) {
            b[i++] = a[11++];
        }

        while (i2 <= high) {
            b[i++] = a[12++];
        }

        for (i = low; i <= high; i++) {
            a[i] = b[i];
        }
    }

    void sort(int low, int high) {
        if (low < high) {
            int mid = (low + high) / 2;

            sort(low, mid);
            sort(mid + 1, high);

            merging(low, mid, high);
        }
    }

    public static void main(String[] args) {
        MergeSort obj = new MergeSort();

        System.out.println("Array before sorting:\n");
        for (int i = 0; i < obj.a.length; i++) {
            System.out.println(obj.a[i]);
        }

        obj.sort(0, obj.a.length - 1);

        System.out.println("\nArray after sorting:\n");
        for (int i = 0; i < obj.a.length; i++) {
            System.out.println(obj.a[i]);
        }
    }
}