class Node {
    int data;
    Node prev, next;

    Node(int data) {
        this.data = data;
    }
}

class DoublyLinkedList {
    Node head, tail;

    public void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
            return;
        }
        tail.next = newNode;
        newNode.prev = tail;
        tail = newNode;
    }

    public void deleteLast() {
        if (tail == null) return; 
        if (head == tail) { 
            head = tail = null;
            return;
        }
        tail = tail.prev;
        tail.next = null;
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();

        dll.append(10);
        dll.append(20);
        dll.append(30);
        dll.append(40);

        System.out.println("Original list:");
        dll.display();

        dll.deleteLast();
        System.out.println("After deleting last node:");
        dll.display();
    }
}
