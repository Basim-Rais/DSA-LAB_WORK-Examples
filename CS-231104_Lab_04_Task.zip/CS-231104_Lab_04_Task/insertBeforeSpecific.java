class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
    }
}

class DoublyLinkedList {
    Node head;

    public void insertBefore(Node next_node, int new_data) {
        if (next_node == null) {
            System.out.println("The given next node cannot be null.");
            return;
        }

        Node newNode = new Node(new_data);
        newNode.next = next_node;
        newNode.prev = next_node.prev;

        if (next_node.prev != null) {
            next_node.prev.next = newNode;
        } else {
            head = newNode; 
        }

        next_node.prev = newNode;
    }

    public void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
        newNode.prev = current;
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();
        dll.append(10);
        dll.append(20);
        dll.append(30);
        dll.append(40);

        System.out.println("Original list:");
        dll.display();

        Node targetNode = dll.head.next; 
        dll.insertBefore(targetNode, 15);

        System.out.println("List after inserting 15 before 20:");
        dll.display();

        targetNode = dll.head; 
        dll.insertBefore(targetNode, 5);

        System.out.println("List after inserting 5 before 10:");
        dll.display();
    }
}
