/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA;

/**
 *
 * @author Pcw
 */
import java.util.Scanner;

public class ArraySearch {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50};
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter ITEM to search: ");
        int item = scanner.nextInt();
        int index = -1;

        for (int i = 0; i < array.length; i++) {
            if (array[i] == item) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            System.out.println("ITEM not found.");
        } else {
            System.out.println("ITEM found at index " + index);
            System.out.println("Right neighbors: " + 
                (index + 1 < array.length ? array[index + 1] : "No right neighbor") + ", " +
                (index + 2 < array.length ? array[index + 2] : "No right neighbor"));
            System.out.println("Left neighbors: " + 
                (index - 1 >= 0 ? array[index - 1] : "No left neighbor") + ", " +
                (index - 2 >= 0 ? array[index - 2] : "No left neighbor"));
        }
    }
}
