/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA;

/**
 *
 * @author Pcw
 */
import java.util.Scanner;

public class ArrayInsertion {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40};
        int[] newArray = new int[array.length + 1];
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter index (K): ");
        int k = scanner.nextInt();
        System.out.print("Enter ITEM (positive integer): ");
        int item = scanner.nextInt();

        if (k >= 0 && k < array.length && item > 0) {
            if (array[k] > item) {
                for (int i = 0; i < k; i++) {
                    newArray[i] = array[i];
                }
                newArray[k] = item;
                for (int i = k; i < array.length; i++) {
                    newArray[i + 1] = array[i];
                }
                System.out.print("Updated Array: ");
                for (int num : newArray) {
                    System.out.print(num + " ");
                }
            } else {
                System.out.println("ITEM at index " + k + " is greater than user's entered ITEM.");
            }
        } else {
            System.out.println("Invalid index or ITEM.");
        }
    }
}


