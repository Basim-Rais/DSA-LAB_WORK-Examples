import java.util.LinkedList;
import java.util.Queue;

class MyQueue {
    LinkedList<Integer> queue = new LinkedList<>();

    public void enqueue(int data) {
        queue.addLast(data);
    }

    public int dequeue() {
        if (!queue.isEmpty()) {
            return queue.removeFirst();
        }
        return -1;
    }

    public void reverseFirstKElements(int k) {
        if (k > queue.size() || k <= 0) return;

        LinkedList<Integer> stack = new LinkedList<>();
        for (int i = 0; i < k; i++) {
            stack.push(queue.removeFirst());
        }

        while (!stack.isEmpty()) {
            queue.addLast(stack.pop());
        }

        for (int i = 0; i < queue.size() - k; i++) {
            queue.addLast(queue.removeFirst());
        }
    }

    public int getMinimum() {
        if (queue.isEmpty()) {
            return -1;
        }

        int min = Integer.MAX_VALUE;
        for (int num : queue) {
            if (num < min) {
                min = num;
            }
        }
        return min;
    }

    public void display() {
        for (int num : queue) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        MyQueue queue = new MyQueue();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);
        queue.enqueue(50);

        System.out.print("Original Queue: ");
        queue.display();

        queue.reverseFirstKElements(3);
        System.out.print("Queue after reversing first 3 elements: ");
        queue.display();

        System.out.println("Minimum element in Queue: " + queue.getMinimum());
    }
}
